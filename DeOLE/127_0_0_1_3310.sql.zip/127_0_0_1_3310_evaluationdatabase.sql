-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3310:3310
-- Generation Time: Jan 06, 2021 at 07:21 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evaluationdatabase`
--
CREATE DATABASE IF NOT EXISTS `evaluationdatabase` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `evaluationdatabase`;

-- --------------------------------------------------------

--
-- Table structure for table `computerscience`
--

CREATE TABLE IF NOT EXISTS `computerscience` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year_of_study` int(11) NOT NULL,
  `semester` float NOT NULL,
  `academic_year` int(11) NOT NULL,
  `unit_code` varchar(10) NOT NULL,
  `unit_name` varchar(60) NOT NULL,
  `lecturer` varchar(50) NOT NULL,
  `lecturer_attendance` int(5) NOT NULL,
  `syllabus_covered` int(5) NOT NULL,
  `resource_material` int(11) DEFAULT NULL,
  `lab_attend` int(5) DEFAULT NULL,
  `date_entered` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`,`unit_code`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `computerscience`
--

INSERT INTO `computerscience` (`id`, `year_of_study`, `semester`, `academic_year`, `unit_code`, `unit_name`, `lecturer`, `lecturer_attendance`, `syllabus_covered`, `resource_material`, `lab_attend`, `date_entered`) VALUES
(27, 2, 2.2, 2020, 'CCS2210', 'Knowledge representation and reasoning', 'Kituku', 3, 2, 3, 0, '2021-01-05 21:41:13'),
(28, 2, 2.2, 2020, 'CCS2211', 'Object-oriented programming', 'Kagiri', 5, 5, 5, 0, '2021-01-05 21:42:09'),
(29, 2, 2.2, 2020, 'CCS2208', 'Computer graphics', 'Moso', 5, 5, 5, 0, '2021-01-05 21:43:05'),
(30, 2, 2.2, 2020, 'CCS2209', 'Computer networks', 'Naivasha', 2, 2, 3, 0, '2021-01-05 21:44:02'),
(31, 2, 2.2, 2020, 'CCS2207', 'Internet application programming', 'Kamundi', 1, 1, 3, 0, '2021-01-05 21:45:08'),
(32, 2, 2.2, 2020, 'SMA2215', 'Vector analysis', 'Keroboto', 3, 3, 4, 0, '2021-01-05 21:46:03');

-- --------------------------------------------------------

--
-- Table structure for table `it`
--

CREATE TABLE IF NOT EXISTS `it` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year_of_study` int(11) NOT NULL,
  `semester` float NOT NULL,
  `academic_year` int(11) NOT NULL,
  `unit_code` varchar(10) NOT NULL,
  `unit_name` varchar(60) NOT NULL,
  `lecturer` varchar(50) NOT NULL,
  `lecturer_attendance` int(5) NOT NULL,
  `syllabus_covered` int(5) NOT NULL,
  `resource_material` int(11) DEFAULT NULL,
  `lab_attend` int(5) DEFAULT NULL,
  `date_entered` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`,`unit_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `it`
--

INSERT INTO `it` (`id`, `year_of_study`, `semester`, `academic_year`, `unit_code`, `unit_name`, `lecturer`, `lecturer_attendance`, `syllabus_covered`, `resource_material`, `lab_attend`, `date_entered`) VALUES
(1, 2, 2.2, 2020, 'CIT2202', 'Operating systems', 'Kariuki', 2, 2, 4, 0, '2021-01-06 05:47:33'),
(2, 2, 2.2, 2020, 'CIT2201', 'Programming', 'Kamau', 4, 4, 2, 0, '2021-01-06 05:48:20');

-- --------------------------------------------------------

--
-- Table structure for table `useradm`
--

CREATE TABLE IF NOT EXISTS `useradm` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `useradm`
--

INSERT INTO `useradm` (`id`, `name`, `password`) VALUES
(1, 'admin', 'adminpass');
